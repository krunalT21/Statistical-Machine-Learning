
%y=normrnd(0,diag(psi));

y=normrnd(zeros(22,1),diag(psi));

